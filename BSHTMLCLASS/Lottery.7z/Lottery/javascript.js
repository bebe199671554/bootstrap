var r;


function getRandom(x) {
    return Math.floor(Math.random() * x) + 1;
    //亂數製造 X=10
};
//再來寫產生威力彩號碼的function
var word = "";

function removeto() {
    $('.carousel').carousel({
        interval: 30
    })


    n = getRandom(r.length) - 1;
    // $('.carousel').carousel({
    //     interval: 500
    // })




    setTimeout(function() {

        $('.carousel').carousel(n);
        console.log("移除" + r[n]);
        document.getElementById("numb").innerHTML += r[n] + " ";
    }, 5000);
    setTimeout(function() {
        $('.carousel').carousel(n - 1);
        $("#b" + r[n]).remove();
        r.splice(n, 1);
        console.log(r);
        $('.carousel').carousel({
            interval: 30
        })
    }, 10000);
    //沒出現過的話就寫進字串裡




};

function carougo() {

}

function getPowerNum(x) {
    //首先我們先宣告一個字串，用來裝要回傳的結果
    var status = '';


    var NewArray = new Array(10);


    var n = 0;





    for (i = 0; i < 10;) {

        n = getRandom(x);
        if (status.indexOf(n) != -1) {
            //用indexOf判斷該數字之前有沒有出現過

        } else {
            //沒出現過的話就寫進字串裡

            status += n + ' ';
            NewArray[i] = n;

            var div = document.createElement("div");
            if (i == 0) { div.className = "carousel-item active lottbg"; } else { div.className = "carousel-item  lottbg"; }

            div.id = 'b' + NewArray[i];

            div.innerHTML = NewArray[i];
            // document.getElementById("userGuess").readOnly = true;
            // document.getElementById("guess").setAttribute("class", "d-none");


            document.getElementById("box").appendChild(div);
            $('.carousel').carousel({
                interval: 30
            })
            $('.carousel').carousel('pause')

            i++
        };
    };
    r = NewArray;
    console.log(r);
    // console.log(NewArray);
    return r;


};

// console.log(arr[0]);